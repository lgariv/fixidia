apt-get remove org.coolstar.sileo
apt-get remove sileoprep
apt-get autoremove
apt-get update
apt-get install ~/APT/installme/* --fix-missing
rm /etc/apt/sources.list.d/sileo.sources
apt full-upgrade
uicache --all
killall -9 SpringBoard
killall -9 backboardd
rm -r ~/APT/installme/
rm -r ~/APT/